let currentTab = "my_reports";
let currentPage = 1;
let allReports = [];
let totalPages = 1;

async function loadDashboardData(tab = currentTab, page = currentPage) {
    currentTab = tab;
    currentPage = page;

    const response = await requestAPI(
        `/api/report/?tab=${tab}&page=${page}`,
        "GET"
    );

    const listContainer = document.getElementById("listContainer");
    const paginationContainer = document.getElementById("paginationContainer");

    if (response && response.status === 200) {
        allReports = response.data.results || [];

        const totalData = response.data.count || 0;
        totalPages = Math.ceil(totalData / 10);

        renderList();
        renderPagination();
        loadSummaryStats();

    } else {
        if (listContainer) {
            listContainer.innerHTML = `
                <div class="col-12 text-center text-muted p-5">
                    <i class="bi bi-exclamation-triangle fs-1"></i>
                    <p>Gagal memuat data laporan.</p>
                </div>
            `;
        }

        if (paginationContainer) {
            paginationContainer.innerHTML = "";
        }
    }
}

async function loadSummaryStats() {
    const response = await requestAPI(
        "/api/report/?tab=my_reports&page_size=1000",
        "GET"
    );

    if (response && response.status === 200) {
        const reports = response.data.results || [];

        const totalDraft = reports.filter(
            report => report.status === "DRAFT"
        ).length;

        const totalDiproses = reports.filter(
            report => report.status === "REPORTED" ||
                      report.status === "VERIFIED"
        ).length;

        const totalSelesai = reports.filter(
            report => report.status === "COMPLETED"
        ).length;

        const draftElement = document.getElementById("totalDraft");
        const diprosesElement = document.getElementById("totalDiproses");
        const selesaiElement = document.getElementById("totalSelesai");

        if (draftElement) {
            draftElement.textContent = totalDraft;
        }

        if (diprosesElement) {
            diprosesElement.textContent = totalDiproses;
        }

        if (selesaiElement) {
            selesaiElement.textContent = totalSelesai;
        }
    }
}

function openReportModal() {
    const reportModalElement = document.getElementById("reportModal");

    if (!reportModalElement) {
        alert("Modal laporan tidak ditemukan.");
        return;
    }

    const reportForm = document.getElementById("reportForm");
    const reportModalLabel = document.getElementById("reportModalLabel");

    if (reportForm) {
        reportForm.reset();
    }

    if (reportModalLabel) {
        reportModalLabel.innerHTML = `
            <i class="bi bi-pencil-square me-2"></i>
            Tambah Laporan Baru
        `;
    }

    const modal = new bootstrap.Modal(reportModalElement);
    modal.show();
}

function renderList() {
    const listContainer = document.getElementById("listContainer");

    if (!listContainer) {
        return;
    }

    if (allReports.length === 0) {
        listContainer.innerHTML = `
            <div class="col-12 text-center text-muted p-5">
                <i class="bi bi-inbox fs-1"></i>
                <p>Belum ada data laporan.</p>
            </div>
        `;
        return;
    }

    listContainer.innerHTML = allReports.map(report => {
        const progress = getProgressValue(report.status);

        return `
            <div class="col-md-6 mb-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="fw-bold mb-0">${report.title}</h5>
                            <span class="badge bg-primary">${report.status}</span>
                        </div>

                        <p class="text-muted mb-1">
                            <i class="bi bi-tag me-1"></i>
                            ${report.category}
                        </p>

                        <p class="text-muted mb-1">
                            <i class="bi bi-geo-alt me-1"></i>
                            ${report.location}
                        </p>

                        <p class="small">${report.description}</p>

                        <p class="small text-muted mb-2">
                            Pelapor: ${report.reporter}
                        </p>

                        <div class="progress mb-2" style="height: 8px;">
                            <div class="progress-bar"
                                 role="progressbar"
                                 style="width: ${progress}%;">
                            </div>
                        </div>

                        <small class="text-muted">
                            Update: ${formatDate(report.updated_at)}
                        </small>
                    </div>
                </div>
            </div>
        `;
    }).join("");
}

function renderPagination() {
    const paginationContainer = document.getElementById("paginationContainer");

    if (!paginationContainer) {
        return;
    }

    if (totalPages <= 1) {
        paginationContainer.innerHTML = "";
        return;
    }

    let buttons = "";

    for (let i = 1; i <= totalPages; i++) {
        buttons += `
            <button class="btn btn-sm ${i === currentPage ? "btn-primary" : "btn-outline-primary"} mx-1"
                    onclick="loadDashboardData('${currentTab}', ${i})">
                ${i}
            </button>
        `;
    }

    paginationContainer.innerHTML = `
        <div class="text-center mt-3">
            ${buttons}
        </div>
    `;
}

function getProgressValue(status) {
    if (status === "DRAFT") {
        return 25;
    }

    if (status === "REPORTED") {
        return 50;
    }

    if (status === "VERIFIED") {
        return 75;
    }

    if (status === "COMPLETED") {
        return 100;
    }

    return 10;
}

function formatDate(dateString) {
    const date = new Date(dateString);

    return date.toLocaleString("id-ID", {
        dateStyle: "medium",
        timeStyle: "short"
    });
}